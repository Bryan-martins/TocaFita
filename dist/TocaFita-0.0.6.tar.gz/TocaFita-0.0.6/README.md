# Toca Fita
#### Esse é um pacote que faz a reprodução de uma lista de musicas

## Instalação
    pip install TocaFita